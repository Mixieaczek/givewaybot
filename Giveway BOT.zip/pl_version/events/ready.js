const { ActivityType } = require('discord.js');

module.exports = {
    name: 'ready',
    once: true,
    execute(client) {
        console.log(`Bot jest gotowy! Obsługuje ${client.guilds.cache.size} serwerów`);
        client.user.setActivity('giveaways!', { type: ActivityType.Watching });
    }
};