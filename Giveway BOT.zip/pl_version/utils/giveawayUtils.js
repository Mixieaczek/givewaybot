const { EmbedBuilder } = require('discord.js');

// Funkcja do tworzenia nowego giveaway
async function createGiveaway(client, message, args) {
    // Sprawdź, czy jest wystarczająco dużo argumentów
    if (args.length < 3) {
        return message.reply('Użycie: !giveaway [czas w minutach] [zwycięzcy] [nagroda]');
    }

    const duration = parseInt(args[0]);
    const winners = parseInt(args[1]);
    const prize = args.slice(2).join(' ');

    // Walidacja wejścia
    if (isNaN(duration) || duration <= 0) {
        return message.reply('Czas musi być poprawną liczbą minut większą od 0.');
    }

    if (isNaN(winners) || winners <= 0) {
        return message.reply('Liczba zwycięzców musi być poprawną liczbą większą od 0.');
    }

    if (!prize) {
        return message.reply('Proszę określić nagrodę dla giveaway.');
    }

    // Utwórz czas zakończenia
    const endTime = Date.now() + duration * 60000;

    // Utwórz embed
    const giveawayEmbed = new EmbedBuilder()
        .setTitle('🎉 GIVEAWAY 🎉')
        .setDescription(`Zareaguj z 🎉, aby wziąć udział!\n\n**Nagroda:** ${prize}\n**Zwycięzcy:** ${winners}\n**Kończy się:** <t:${Math.floor(endTime / 1000)}:R>`)
        .setColor('#FF5733')
        .setFooter({ text: `ID giveaway: ${Date.now()}` })
        .setTimestamp(endTime);

    // Wyślij embed
    const giveawayMessage = await message.channel.send({ embeds: [giveawayEmbed] });
    
    // Dodaj reakcję
    await giveawayMessage.react('🎉');

    // Przechowaj dane giveaway
    const giveawayData = {
        messageId: giveawayMessage.id,
        channelId: giveawayMessage.channel.id,
        guildId: message.guild.id,
        prize: prize,
        winners: winners,
        endTime: endTime,
        hostId: message.author.id,
        ended: false
    };

    // Dodaj do kolekcji
    client.giveaways.set(giveawayMessage.id, giveawayData);

    // Ustaw timeout na zakończenie giveaway
    setTimeout(() => {
        endGiveaway(client, giveawayMessage.id);
    }, duration * 60000);
}

// Funkcja do zakończenia giveaway
async function endGiveaway(client, messageId) {
    const giveawayData = client.giveaways.get(messageId);
    
    if (!giveawayData || giveawayData.ended) return;

    try {
        const guild = await client.guilds.fetch(giveawayData.guildId);
        const channel = await guild.channels.fetch(giveawayData.channelId);
        const giveawayMessage = await channel.messages.fetch(messageId);
        
        // Pobierz wszystkich użytkowników, którzy zareagowali z 🎉, z wyjątkiem bota
        const reaction = giveawayMessage.reactions.cache.get('🎉');
        if (!reaction) return;
        
        await reaction.users.fetch();
        const validEntrants = reaction.users.cache.filter(user => !user.bot);
        
        // Oznacz giveaway jako zakończony
        giveawayData.ended = true;
        client.giveaways.set(messageId, giveawayData);

        // Wybierz zwycięzców
        const winners = [];
        if (validEntrants.size > 0) {
            const entriesArray = Array.from(validEntrants.values());
            
            for (let i = 0; i < Math.min(giveawayData.winners, entriesArray.length); i++) {
                const winnerIndex = Math.floor(Math.random() * entriesArray.length);
                winners.push(entriesArray[winnerIndex]);
                entriesArray.splice(winnerIndex, 1);
            }
        }

        // Zaktualizuj embed
        const endedEmbed = new EmbedBuilder()
            .setTitle('🎉 GIVEAWAY ZAKOŃCZONY 🎉')
            .setDescription(`**Nagroda:** ${giveawayData.prize}\n**Zwycięzcy:** ${winners.length > 0 ? winners.map(w => `<@${w.id}>`).join(', ') : 'Brak ważnych uczestników'}`)
            .setColor('#36393F')
            .setFooter({ text: `ID giveaway: ${messageId}` })
            .setTimestamp();

        await giveawayMessage.edit({ embeds: [endedEmbed] });

        // Wyślij ogłoszenie
        if (winners.length > 0) {
            channel.send({
                content: `Gratulacje ${winners.map(w => `<@${w.id}>`).join(', ')}! Wygraliście: **${giveawayData.prize}**`,
                allowedMentions: { users: winners.map(w => w.id) }
            });
        } else {
            channel.send(`Brak ważnych uczestników dla giveaway: **${giveawayData.prize}**`);
        }
    } catch (error) {
        console.error('Błąd podczas kończenia giveaway:', error);
    }
}

// Funkcja do ponownego losowania zwycięzców
async function rerollGiveaway(client, message, args) {
    if (!args[0]) {
        return message.reply('Proszę podać ID wiadomości giveaway, aby ponownie losować.');
    }

    const messageId = args[0];
    const giveawayData = client.giveaways.get(messageId);

    if (!giveawayData) {
        return message.reply('Giveaway nie znaleziono.');
    }

    if (!giveawayData.ended) {
        return message.reply('Ten giveaway jeszcze się nie zakończył.');
    }

    try {
        const guild = await client.guilds.fetch(giveawayData.guildId);
        const channel = await guild.channels.fetch(giveawayData.channelId);
        const giveawayMessage = await channel.messages.fetch(messageId);
        
        // Pobierz wszystkich użytkowników, którzy zareagowali z 🎉, z wyjątkiem bota
        const reaction = giveawayMessage.reactions.cache.get('🎉');
        if (!reaction) {
            return message.reply('Nie można znaleźć reakcji na ten giveaway.');
        }
        
        await reaction.users.fetch();
        const validEntrants = reaction.users.cache.filter(user => !user.bot);
        
        // Wybierz nowych zwycięzców
        const winners = [];
        if (validEntrants.size > 0) {
            const entriesArray = Array.from(validEntrants.values());
            
            const numWinners = args[1] ? parseInt(args[1]) : giveawayData.winners;
            for (let i = 0; i < Math.min(numWinners, entriesArray.length); i++) {
                const winnerIndex = Math.floor(Math.random() * entriesArray.length);
                winners.push(entriesArray[winnerIndex]);
                entriesArray.splice(winnerIndex, 1);
            }
        }

        // Wyślij ogłoszenie
        if (winners.length > 0) {
            channel.send({
                content: `Ponowne losowanie! Gratulacje ${winners.map(w => `<@${w.id}>`).join(', ')}! Wygraliście: **${giveawayData.prize}**`,
                allowedMentions: { users: winners.map(w => w.id) }
            });
        } else {
            channel.send(`Brak ważnych uczestników dla ponownego losowania: **${giveawayData.prize}**`);
        }

        return message.reply('Giveaway ponownie wylosowany!');
    } catch (error) {
        console.error('Błąd podczas ponownego losowania giveaway:', error);
        return message.reply('Wystąpił błąd podczas ponownego losowania giveaway.');
    }
}

module.exports = {
    createGiveaway,
    endGiveaway,
    rerollGiveaway
};