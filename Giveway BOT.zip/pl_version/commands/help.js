const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'help',
    description: 'Pokazuje wszystkie dostępne komendy',
    async execute(message, args, client) {
        const prefix = process.env.PREFIX;
        
        const helpEmbed = new EmbedBuilder()
            .setTitle('🎉 Pomoc Bota Giveaway 🎉')
            .setColor('#FF5733')
            .setDescription('Oto wszystkie dostępne komendy:')
            .addFields(
                { name: `${prefix}giveaway [czas] [zwycięzcy] [nagroda]`, value: 'Tworzy nowy giveaway. Czas jest w minutach.' },
                { name: `${prefix}end [messageId]`, value: 'Kończy giveaway przed czasem.' },
                { name: `${prefix}reroll [messageId] [zwycięzcy]`, value: 'Ponownie losuje zwycięzców zakończonego giveaway. Parametr zwycięzców jest opcjonalny.' },
                { name: `${prefix}help`, value: 'Pokazuje tę wiadomość pomocy.' }
            )
            .setFooter({ text: 'Wymagane uprawnienia: Zarządzanie wiadomościami' })
            .setTimestamp();

        return message.channel.send({ embeds: [helpEmbed] });
    }
};