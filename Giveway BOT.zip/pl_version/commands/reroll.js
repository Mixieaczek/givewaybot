const { rerollGiveaway } = require('../utils/giveawayUtils');
const { PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'reroll',
    description: 'Ponownie losuje zwycięzców giveaway',
    async execute(message, args, client) {
        // Sprawdź, czy użytkownik ma uprawnienia do ponownego losowania giveaway
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return message.reply('Nie masz uprawnień do ponownego losowania giveaway.');
        }

        return rerollGiveaway(client, message, args);
    }
};