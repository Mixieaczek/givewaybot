const { createGiveaway } = require('../utils/giveawayUtils');
   const { PermissionsBitField } = require('discord.js');

   module.exports = {
       name: 'giveaway',
       description: 'Tworzy nowy giveaway',
       async execute(message, args, client) {
           // Sprawdź, czy użytkownik ma uprawnienia do tworzenia giveaway
           if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
               return message.reply('Nie masz uprawnień do tworzenia giveaway.');
           }

           return createGiveaway(client, message, args);
       }
   };