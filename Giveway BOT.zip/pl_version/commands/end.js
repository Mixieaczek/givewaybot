const { endGiveaway } = require('../utils/giveawayUtils');
const { PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'end',
    description: 'Kończy giveaway przed czasem',
    async execute(message, args, client) {
        // Sprawdź, czy użytkownik ma uprawnienia do kończenia giveaway
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return message.reply('Nie masz uprawnień do kończenia giveaway.');
        }

        if (!args[0]) {
            return message.reply('Proszę podać ID wiadomości giveaway, aby zakończyć.');
        }

        const messageId = args[0];
        const giveawayData = client.giveaways.get(messageId);

        if (!giveawayData) {
            return message.reply('Giveaway nie znaleziono.');
        }

        if (giveawayData.ended) {
            return message.reply('Ten giveaway już się zakończył.');
        }

        // Zakończ giveaway
        await endGiveaway(client, messageId);
    }
};