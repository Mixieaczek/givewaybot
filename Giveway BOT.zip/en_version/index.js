const { Client, GatewayIntentBits, EmbedBuilder, PermissionsBitField, Permissions, MessageManager, Embed, Collection, Events, ActivityType } = require('discord.js');
const fs = require('fs');
const client = new Client({ intents: [
  GatewayIntentBits.Guilds, 
  GatewayIntentBits.GuildMessages,
  GatewayIntentBits.MessageContent,
  GatewayIntentBits.GuildMembers,
  GatewayIntentBits.GuildMessageReactions
] }); 
require('dotenv').config();

client.commands = new Collection();

// Create commands folder if it doesn't exist
if (!fs.existsSync('./commands')) {
  fs.mkdirSync('./commands');
}

// Command handler
const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));
for (const file of commandFiles) {
  const command = require(`./commands/${file}`);
  client.commands.set(command.name, command);
}

// Create events folder if it doesn't exist
if (!fs.existsSync('./events')) {
  fs.mkdirSync('./events');
}

// Event handler
const eventFiles = fs.readdirSync('./events').filter(file => file.endsWith('.js'));
for (const file of eventFiles) {
  const event = require(`./events/${file}`);
  if (event.once) {
    client.once(event.name, (...args) => event.execute(...args, client));
  } else {
    client.on(event.name, (...args) => event.execute(...args, client));
  }
}

// Main giveaway storage
client.giveaways = new Collection();

// When the client is ready, run this code
client.once(Events.ClientReady, () => {
  console.log(`Logged in as ${client.user.tag}!`);
  client.user.setActivity('giveaways!', { type: ActivityType.Watching });
});

client.login(process.env.TOKEN); 