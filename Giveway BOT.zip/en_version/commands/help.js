const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'help',
    description: 'Shows all available commands',
    async execute(message, args, client) {
        const prefix = process.env.PREFIX;
        
        const helpEmbed = new EmbedBuilder()
            .setTitle('🎉 Giveaway Bot Help 🎉')
            .setColor('#FF5733')
            .setDescription('Here are all the available commands:')
            .addFields(
                { name: `${prefix}giveaway [duration] [winners] [prize]`, value: 'Creates a new giveaway. Duration is in minutes.' },
                { name: `${prefix}end [messageId]`, value: 'Ends a giveaway early.' },
                { name: `${prefix}reroll [messageId] [winners]`, value: 'Rerolls the winners of an ended giveaway. Winners parameter is optional.' },
                { name: `${prefix}help`, value: 'Shows this help message.' }
            )
            .setFooter({ text: 'Required permissions: Manage Messages' })
            .setTimestamp();

        return message.channel.send({ embeds: [helpEmbed] });
    }
}; 