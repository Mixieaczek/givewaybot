const { createGiveaway } = require('../utils/giveawayUtils');
const { PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'giveaway',
    description: 'Creates a new giveaway',
    async execute(message, args, client) {
        // Check if user has permission to create giveaways
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return message.reply('You do not have permission to create giveaways.');
        }

        return createGiveaway(client, message, args);
    }
}; 