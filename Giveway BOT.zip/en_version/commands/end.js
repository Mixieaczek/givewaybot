const { endGiveaway } = require('../utils/giveawayUtils');
const { PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'end',
    description: 'Ends a giveaway early',
    async execute(message, args, client) {
        // Check if user has permission to end giveaways
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return message.reply('You do not have permission to end giveaways.');
        }

        if (!args[0]) {
            return message.reply('Please provide a giveaway message ID to end.');
        }

        const messageId = args[0];
        const giveawayData = client.giveaways.get(messageId);

        if (!giveawayData) {
            return message.reply('Giveaway not found.');
        }

        if (giveawayData.ended) {
            return message.reply('That giveaway has already ended.');
        }

        // End the giveaway
        await endGiveaway(client, messageId);
    }
}; 