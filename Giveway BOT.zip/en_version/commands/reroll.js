const { rerollGiveaway } = require('../utils/giveawayUtils');
const { PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'reroll',
    description: 'Rerolls the winners of a giveaway',
    async execute(message, args, client) {
        // Check if user has permission to reroll giveaways
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return message.reply('You do not have permission to reroll giveaways.');
        }

        return rerollGiveaway(client, message, args);
    }
}; 