const { EmbedBuilder } = require('discord.js');

// Function to create a new giveaway
async function createGiveaway(client, message, args) {
    // Check if there are enough arguments
    if (args.length < 3) {
        return message.reply('Usage: !giveaway [duration in minutes] [winners] [prize]');
    }

    const duration = parseInt(args[0]);
    const winners = parseInt(args[1]);
    const prize = args.slice(2).join(' ');

    // Validate input
    if (isNaN(duration) || duration <= 0) {
        return message.reply('Duration must be a valid number of minutes greater than 0.');
    }

    if (isNaN(winners) || winners <= 0) {
        return message.reply('Number of winners must be a valid number greater than 0.');
    }

    if (!prize) {
        return message.reply('Please specify a prize for the giveaway.');
    }

    // Create end time
    const endTime = Date.now() + duration * 60000;

    // Create embed
    const giveawayEmbed = new EmbedBuilder()
        .setTitle('🎉 GIVEAWAY 🎉')
        .setDescription(`React with 🎉 to enter!\n\n**Prize:** ${prize}\n**Winners:** ${winners}\n**Ends:** <t:${Math.floor(endTime / 1000)}:R>`)
        .setColor('#FF5733')
        .setFooter({ text: `Giveaway ID: ${Date.now()}` })
        .setTimestamp(endTime);

    // Send the embed
    const giveawayMessage = await message.channel.send({ embeds: [giveawayEmbed] });
    
    // Add reaction
    await giveawayMessage.react('🎉');

    // Store giveaway data
    const giveawayData = {
        messageId: giveawayMessage.id,
        channelId: giveawayMessage.channel.id,
        guildId: message.guild.id,
        prize: prize,
        winners: winners,
        endTime: endTime,
        hostId: message.author.id,
        ended: false
    };

    // Add to collection
    client.giveaways.set(giveawayMessage.id, giveawayData);

    // Set timeout to end the giveaway
    setTimeout(() => {
        endGiveaway(client, giveawayMessage.id);
    }, duration * 60000);
}

// Function to end a giveaway
async function endGiveaway(client, messageId) {
    const giveawayData = client.giveaways.get(messageId);
    
    if (!giveawayData || giveawayData.ended) return;

    try {
        const guild = await client.guilds.fetch(giveawayData.guildId);
        const channel = await guild.channels.fetch(giveawayData.channelId);
        const giveawayMessage = await channel.messages.fetch(messageId);
        
        // Get all users who reacted with 🎉, excluding the bot
        const reaction = giveawayMessage.reactions.cache.get('🎉');
        if (!reaction) return;
        
        await reaction.users.fetch();
        const validEntrants = reaction.users.cache.filter(user => !user.bot);
        
        // Mark giveaway as ended
        giveawayData.ended = true;
        client.giveaways.set(messageId, giveawayData);

        // Choose winners
        const winners = [];
        if (validEntrants.size > 0) {
            const entriesArray = Array.from(validEntrants.values());
            
            for (let i = 0; i < Math.min(giveawayData.winners, entriesArray.length); i++) {
                const winnerIndex = Math.floor(Math.random() * entriesArray.length);
                winners.push(entriesArray[winnerIndex]);
                entriesArray.splice(winnerIndex, 1);
            }
        }

        // Update embed
        const endedEmbed = new EmbedBuilder()
            .setTitle('🎉 GIVEAWAY ENDED 🎉')
            .setDescription(`**Prize:** ${giveawayData.prize}\n**Winners:** ${winners.length > 0 ? winners.map(w => `<@${w.id}>`).join(', ') : 'No valid participants'}`)
            .setColor('#36393F')
            .setFooter({ text: `Giveaway ID: ${messageId}` })
            .setTimestamp();

        await giveawayMessage.edit({ embeds: [endedEmbed] });

        // Send announcement
        if (winners.length > 0) {
            channel.send({
                content: `Congratulations ${winners.map(w => `<@${w.id}>`).join(', ')}! You won: **${giveawayData.prize}**`,
                allowedMentions: { users: winners.map(w => w.id) }
            });
        } else {
            channel.send(`No valid participants for the giveaway: **${giveawayData.prize}**`);
        }
    } catch (error) {
        console.error('Error ending giveaway:', error);
    }
}

// Function to reroll winners
async function rerollGiveaway(client, message, args) {
    if (!args[0]) {
        return message.reply('Please provide a giveaway message ID to reroll.');
    }

    const messageId = args[0];
    const giveawayData = client.giveaways.get(messageId);

    if (!giveawayData) {
        return message.reply('Giveaway not found.');
    }

    if (!giveawayData.ended) {
        return message.reply('That giveaway has not ended yet.');
    }

    try {
        const guild = await client.guilds.fetch(giveawayData.guildId);
        const channel = await guild.channels.fetch(giveawayData.channelId);
        const giveawayMessage = await channel.messages.fetch(messageId);
        
        // Get all users who reacted with 🎉, excluding the bot
        const reaction = giveawayMessage.reactions.cache.get('🎉');
        if (!reaction) {
            return message.reply('Could not find reactions on that giveaway.');
        }
        
        await reaction.users.fetch();
        const validEntrants = reaction.users.cache.filter(user => !user.bot);
        
        // Choose new winners
        const winners = [];
        if (validEntrants.size > 0) {
            const entriesArray = Array.from(validEntrants.values());
            
            const numWinners = args[1] ? parseInt(args[1]) : giveawayData.winners;
            for (let i = 0; i < Math.min(numWinners, entriesArray.length); i++) {
                const winnerIndex = Math.floor(Math.random() * entriesArray.length);
                winners.push(entriesArray[winnerIndex]);
                entriesArray.splice(winnerIndex, 1);
            }
        }

        // Send announcement
        if (winners.length > 0) {
            channel.send({
                content: `Reroll! Congratulations ${winners.map(w => `<@${w.id}>`).join(', ')}! You won: **${giveawayData.prize}**`,
                allowedMentions: { users: winners.map(w => w.id) }
            });
        } else {
            channel.send(`No valid participants for the reroll of: **${giveawayData.prize}**`);
        }
    } catch (error) {
        console.error('Error rerolling giveaway:', error);
        return message.reply('An error occurred while rerolling the giveaway.');
    }
}

module.exports = {
    createGiveaway,
    endGiveaway,
    rerollGiveaway
}; 