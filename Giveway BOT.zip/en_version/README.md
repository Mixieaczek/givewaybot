# Discord Giveaway Bot

A simple Discord bot for creating and managing giveaways in your server.

## Features

- Create giveaways with customizable duration, prize, and winner count
- End giveaways early
- Reroll winners for giveaways
- Simple permission system (requires Manage Messages permission)

## Setup

1. Clone this repository
2. Install dependencies:
   ```
   npm install
   ```
3. Create a `.env` file based on the `env.example` file:
   ```
   TOKEN=your_discord_bot_token
   PREFIX=!
   ```
4. Create a Discord bot and get your token:
   - Go to the [Discord Developer Portal](https://discord.com/developers/applications)
   - Create a new application
   - Go to the "Bot" tab and click "Add Bot"
   - Copy the token and add it to your `.env` file
   - Enable necessary Intents (Message Content, Server Members, etc.)

5. Invite the bot to your server:
   - Go to the "OAuth2" tab in the Developer Portal
   - Select "bot" under scopes
   - Select the following permissions:
     - Read Messages/View Channels
     - Send Messages
     - Manage Messages
     - Embed Links
     - Add Reactions
     - Read Message History
   - Copy the generated URL and open it in your browser to invite the bot

6. Start the bot:
   ```
   node index.js
   ```

## Commands

- `!giveaway [duration in minutes] [winners] [prize]` - Creates a new giveaway
- `!end [message ID]` - Ends a giveaway early
- `!reroll [message ID] [winners]` - Rerolls winners for an ended giveaway
- `!help` - Shows all available commands

## Examples

- `!giveaway 60 1 Discord Nitro` - Creates a 1-hour giveaway for Discord Nitro with 1 winner
- `!giveaway 1440 3 $10 Steam Gift Card` - Creates a 24-hour giveaway for a Steam Gift Card with 3 winners
- `!end 123456789012345678` - Ends the giveaway with the provided message ID
- `!reroll 123456789012345678 2` - Rerolls 2 winners for the giveaway with the provided message ID

## Required Permissions

Users need the "Manage Messages" permission to create, end, and reroll giveaways. 