const { ActivityType } = require('discord.js');

module.exports = {
    name: 'ready',
    once: true,
    execute(client) {
        console.log(`Bot is ready! Serving in ${client.guilds.cache.size} servers`);
        client.user.setActivity('giveaways!', { type: ActivityType.Watching });
    }
}; 