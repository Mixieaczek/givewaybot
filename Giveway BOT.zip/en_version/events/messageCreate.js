module.exports = {
    name: 'messageCreate',
    once: false,
    async execute(message, client) {
        // Ignore bot messages
        if (message.author.bot) return;
        
        // Check if the message starts with the prefix
        const prefix = process.env.PREFIX;
        if (!message.content.startsWith(prefix)) return;

        // Get the command name and arguments
        const args = message.content.slice(prefix.length).trim().split(/ +/);
        const commandName = args.shift().toLowerCase();

        // Get the command from the collection
        const command = client.commands.get(commandName);

        // If command doesn't exist, return
        if (!command) return;

        // Execute the command
        try {
            await command.execute(message, args, client);
        } catch (error) {
            console.error(`Error executing ${commandName} command:`, error);
            message.reply('There was an error trying to execute that command!');
        }
    }
}; 